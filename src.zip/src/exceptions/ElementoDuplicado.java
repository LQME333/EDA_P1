package exceptions;

public class ElementoDuplicado extends Exception{
    public ElementoDuplicado(){
        super("Elemento Duplicado");
    }
}
