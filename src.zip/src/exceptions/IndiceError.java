package exceptions;
import exceptions.IndiceError;
import exceptions.ElementoNoEncontrado;
import exceptions.ElementoDuplicado;

public class IndiceError extends Exception{
    public IndiceError(){
        super("Error");
    }
}


